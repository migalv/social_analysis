package es.uam.eps.bmi.recsys.data;

/**
 *
 * @author pablo
 */
public class StringParser implements Parser<String> {
    public String parse(String value) {
        return value;
    }
}
