package es.uam.eps.bmi.recsys.recommender.similarity;

/**
 *
 * @author pablo
 */
public interface Similarity {
    public double sim(int x, int y);
}
